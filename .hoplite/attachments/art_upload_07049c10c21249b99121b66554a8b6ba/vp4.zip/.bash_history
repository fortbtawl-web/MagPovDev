python run.py migrate
EXIT
exit
python run.py migrate
exit
